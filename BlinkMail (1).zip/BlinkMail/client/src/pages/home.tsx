import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import ExperienceTimeline from "@/components/experience-timeline";
import EmailTemplatePreview from "@/components/email-template-preview";
import CampaignResults from "@/components/campaign-results";
import ProcessSection from "@/components/process-section";
import SkillsSection from "@/components/skills-section";
import ContactSection from "@/components/contact-section";

export default function Home() {
  return (
    <div className="bg-dark-navy text-white font-inter">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <ExperienceTimeline />
      <EmailTemplatePreview />
      <CampaignResults />
      <ProcessSection />
      <SkillsSection />
      <ContactSection />
      
      {/* Footer */}
      <footer className="py-12 px-6 border-t border-gray-800">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-gray-400 mb-4">
            Ready to transform your marketing? I'm currently open to internship opportunities in fintech, AI-led marketing, or digital transformation.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm text-gray-500">
            <span className="flex items-center">
              <i className="fas fa-check-circle text-green-400 mr-2"></i>
              Available for immediate opportunities
            </span>
            <span className="flex items-center">
              <i className="fas fa-globe text-blue-accent mr-2"></i>
              Remote & On-site friendly
            </span>
            <span className="flex items-center">
              <i className="fas fa-clock text-purple-accent mr-2"></i>
              Quick response guaranteed
            </span>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800">
            <p className="text-xs text-gray-500">
              Made with <i className="fas fa-heart text-red-400"></i> by Harshit Aggarwal • AI Email Marketing Expert
            </p>
          </div>
        </div>
      </footer>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <a 
          href="#contact" 
          className="gradient-bg text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform duration-300 animate-glow"
          data-testid="floating-contact-button"
        >
          <i className="fas fa-comments text-xl"></i>
        </a>
      </div>
    </div>
  );
}
