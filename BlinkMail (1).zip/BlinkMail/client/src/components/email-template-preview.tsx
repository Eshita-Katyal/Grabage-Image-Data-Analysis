import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

type TemplateType = 'welcome' | 'promotional' | 'newsletter';

interface TemplateData {
  id: TemplateType;
  title: string;
  description: string;
  metric: string;
  metricColor: string;
}

const templates: TemplateData[] = [
  {
    id: 'welcome',
    title: 'Welcome Series - Day 1',
    description: 'Welcome to the future of email marketing with AI-powered personalization and data-driven insights.',
    metric: '35% Open Rate',
    metricColor: 'bg-blue-accent'
  },
  {
    id: 'promotional', 
    title: 'Special Offer',
    description: 'Limited time 50% off everything - Use code SAVE50',
    metric: '42% CTR',
    metricColor: 'bg-purple-accent'
  },
  {
    id: 'newsletter',
    title: 'Weekly Insights',
    description: 'Your weekly dose of AI marketing insights and trends',
    metric: '92% Engagement',
    metricColor: 'bg-green-400'
  }
];

export default function EmailTemplatePreview() {
  const [activeTemplate, setActiveTemplate] = useState<TemplateType>('welcome');
  const [email, setEmail] = useState('');
  const { toast } = useToast();

  const handleSendTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address to receive the template.",
        variant: "destructive",
      });
      return;
    }

    // Here you would normally send the email via API
    toast({
      title: "Template Sent!",
      description: "Check your inbox for the email template and detailed breakdown.",
    });
    setEmail('');
  };

  const getTemplateContent = () => {
    switch (activeTemplate) {
      case 'welcome':
        return (
          <div className="space-y-4">
            <div className="bg-darker rounded-xl p-6 border border-gray-700 mb-4">
              <h4 className="font-bold mb-2">Welcome Series - Day 1</h4>
              <p className="text-gray-300 text-sm mb-3">Welcome to the future of email marketing with AI-powered personalization and data-driven insights.</p>
              <span className="inline-block bg-blue-accent text-white px-3 py-1 rounded text-xs">35% Open Rate</span>
            </div>
            <div className="bg-darker rounded-xl p-6 border border-gray-700">
              <h4 className="font-bold mb-2">Welcome Series</h4>
              <p className="text-gray-300 text-sm mb-3">Welcome to our community of AI email marketing experts!</p>
              <span className="inline-block bg-blue-accent text-white px-3 py-1 rounded text-xs">31% Open Rate</span>
            </div>
          </div>
        );
      case 'promotional':
        return (
          <div className="bg-darker rounded-xl p-6 border border-gray-700">
            <h4 className="font-bold mb-2">Special Offer</h4>
            <p className="text-gray-300 text-sm mb-3">Limited time 50% off everything - Use code SAVE50</p>
            <span className="inline-block bg-purple-accent text-white px-3 py-1 rounded text-xs">42% CTR</span>
          </div>
        );
      case 'newsletter':
        return (
          <div className="bg-darker rounded-xl p-6 border border-gray-700">
            <h4 className="font-bold mb-2">Weekly Insights</h4>
            <p className="text-gray-300 text-sm mb-3">Your weekly dose of AI marketing insights and trends</p>
            <span className="inline-block bg-green-400 text-white px-3 py-1 rounded text-xs">92% Engagement</span>
          </div>
        );
    }
  };

  return (
    <section id="templates" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-8">Live Email Preview</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            See our high-converting templates in action
          </p>
        </div>

        <div className="bg-darker/50 rounded-2xl border border-gray-800 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            {/* Template Selection */}
            <div className="p-8 border-r border-gray-800">
              <h3 className="text-2xl font-bold mb-6">Choose Your Template</h3>
              
              {/* Template Tabs */}
              <div className="flex border-b border-gray-700 mb-6">
                {templates.map((template) => (
                  <button
                    key={template.id}
                    onClick={() => setActiveTemplate(template.id)}
                    className={`px-4 py-2 transition-colors ${
                      activeTemplate === template.id
                        ? 'text-blue-accent border-b-2 border-blue-accent'
                        : 'text-gray-400 hover:text-white'
                    }`}
                    data-testid={`tab-${template.id}`}
                  >
                    {template.id.charAt(0).toUpperCase() + template.id.slice(1)}
                  </button>
                ))}
              </div>

              {/* Template Content */}
              <div data-testid={`template-content-${activeTemplate}`}>
                {getTemplateContent()}
              </div>
            </div>

            {/* Preview Pane */}
            <div className="p-8">
              <h3 className="text-2xl font-bold mb-6">Live Preview</h3>
              <div className="bg-white rounded-xl p-8 text-gray-800 min-h-[300px] flex items-center justify-center" data-testid="email-preview-pane">
                <div className="text-center text-gray-400">
                  <i className="fas fa-envelope text-6xl mb-4"></i>
                  <p>Select a template to see the live preview</p>
                </div>
              </div>

              {/* Get Template Form */}
              <div className="mt-8">
                <div className="flex items-center mb-4">
                  <i className="fas fa-star text-yellow-400 mr-2"></i>
                  <h4 className="font-bold">Get Free Email Template</h4>
                </div>
                <form onSubmit={handleSendTemplate} className="space-y-4">
                  <Input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-darker border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-accent focus:outline-none"
                    data-testid="input-email-template"
                  />
                  <Button
                    type="submit"
                    className="w-full gradient-bg text-white px-6 py-3 rounded-lg font-semibold hover:scale-105 transition-transform duration-300"
                    data-testid="button-send-template"
                  >
                    <i className="fas fa-paper-plane mr-2"></i>
                    Send Template to My Inbox
                  </Button>
                </form>
                <p className="text-xs text-gray-400 text-center mt-4">
                  <i className="fas fa-shield-alt mr-1"></i>
                  Guaranteed inbox delivery • No spam • Unsubscribe anytime
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
