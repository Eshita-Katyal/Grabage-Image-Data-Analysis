export default function ProcessSection() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-8">
            From Data to <span className="gradient-text">$47K Revenue</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            My 3-step AI-powered process that transforms boring email blasts into revenue-generating machines
          </p>
        </div>

        <div className="space-y-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-accent to-blue-accent rounded-lg flex items-center justify-center text-2xl font-bold mr-4">
                  01
                </div>
                <h3 className="text-3xl font-bold">Deep Data Dive</h3>
              </div>
              <h4 className="text-xl text-blue-accent mb-4">Understanding Your Audience</h4>
              <p className="text-gray-300 mb-6 leading-relaxed">
                I analyze your customer data like a detective, uncovering hidden patterns and preferences that most marketers miss.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Customer journey mapping</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Behavioral pattern analysis</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Purchase history insights</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Engagement trend identification</span>
                </div>
              </div>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Email marketing analytics dashboard" 
                className="rounded-2xl shadow-2xl"
                data-testid="img-analytics-dashboard"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <img 
                src="https://images.unsplash.com/photo-1559028006-448665bd7c7f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Digital design workspace" 
                className="rounded-2xl shadow-2xl"
                data-testid="img-design-workspace"
              />
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-accent to-blue-accent rounded-lg flex items-center justify-center text-2xl font-bold mr-4">
                  02
                </div>
                <h3 className="text-3xl font-bold">Design Psychology</h3>
              </div>
              <h4 className="text-xl text-purple-accent mb-4">Creating Irresistible Visuals</h4>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Every color, font, and layout choice is strategically designed to trigger the right emotions and drive action.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Psychology-based color selection</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Mobile-first responsive design</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Strategic CTA placement</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Brand-consistent styling</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-accent to-blue-accent rounded-lg flex items-center justify-center text-2xl font-bold mr-4">
                  03
                </div>
                <h3 className="text-3xl font-bold">AI Personalization</h3>
              </div>
              <h4 className="text-xl text-green-400 mb-4">Making Every Email Feel Personal</h4>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Advanced AI algorithms personalize every single element, making each recipient feel like the email was written just for them.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Dynamic content generation</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Personalized subject lines</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Optimal send time prediction</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-3"></i>
                  <span>Individual product recommendations</span>
                </div>
              </div>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="AI technology and machine learning visualization" 
                className="rounded-2xl shadow-2xl"
                data-testid="img-ai-technology"
              />
            </div>
          </div>
        </div>

        <div className="text-center mt-16">
          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">The Result?</h3>
            <p className="text-xl text-gray-300">
              Emails that don't just get opened—they get clicked, shared, and converted. My clients see an average of{' '}
              <span className="gradient-text font-bold">200% increase</span> in email revenue within the first 30 days.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
