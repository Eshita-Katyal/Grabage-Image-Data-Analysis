import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    // Here you would normally send the form data to your backend
    toast({
      title: "Message Sent!",
      description: "Thank you for your interest! I will get back to you within 2 hours.",
    });
    
    setFormData({
      name: '',
      email: '',
      company: '',
      message: ''
    });
  };

  return (
    <section id="contact" className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-8">
            Ready to Turn Your <span className="gradient-text">Emails Into Revenue?</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Stop losing money on emails that get ignored. Let's create AI-powered campaigns that your customers actually want to read and buy from.
          </p>
          <p className="text-blue-accent font-semibold">Free consultation • Quick response • Proven results</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
            <h3 className="text-2xl font-bold mb-6">Let's Start Your Success Story</h3>
            <p className="text-gray-300 mb-6">Tell me about your business and email marketing goals</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Input
                  type="text"
                  name="name"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-darker border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-accent focus:outline-none"
                  data-testid="input-name"
                />
              </div>
              <div>
                <Input
                  type="email"
                  name="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-darker border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-accent focus:outline-none"
                  data-testid="input-email"
                />
              </div>
              <div>
                <Input
                  type="text"
                  name="company"
                  placeholder="Company Name"
                  value={formData.company}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-darker border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-accent focus:outline-none"
                  data-testid="input-company"
                />
              </div>
              <div>
                <Textarea
                  name="message"
                  placeholder="Tell me about your email marketing challenges..."
                  rows={4}
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-darker border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-accent focus:outline-none resize-none"
                  data-testid="textarea-message"
                />
              </div>
              <Button
                type="submit"
                className="w-full gradient-bg text-white px-6 py-4 rounded-lg font-semibold text-lg hover:scale-105 transition-transform duration-300"
                data-testid="button-submit-contact"
              >
                <i className="fas fa-rocket mr-2"></i>
                Start My Revenue Transformation
              </Button>
            </form>

            <div className="mt-6 space-y-2 text-sm text-gray-400">
              <div className="flex items-center">
                <i className="fas fa-clock mr-2 text-blue-accent"></i>
                <span>🚀 I typically respond within 2 hours</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-lightbulb mr-2 text-purple-accent"></i>
                <span>💡 Free consultation to discuss your email strategy</span>
              </div>
            </div>
          </div>

          {/* Direct Contact */}
          <div className="space-y-8">
            <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
              <h3 className="text-2xl font-bold mb-6">Direct Contact</h3>
              <div className="space-y-4">
                <a 
                  href="mailto:harshitanshu18@gmail.com" 
                  className="flex items-center space-x-4 p-4 bg-darker rounded-lg border border-gray-700 hover:border-blue-accent transition-colors group"
                  data-testid="contact-email"
                >
                  <i className="fas fa-envelope text-blue-accent text-xl"></i>
                  <div>
                    <div className="font-semibold group-hover:text-blue-accent transition-colors">Email Me</div>
                    <div className="text-sm text-gray-400">harshitanshu18@gmail.com</div>
                  </div>
                </a>
                <a 
                  href="https://wa.me/919413173801" 
                  className="flex items-center space-x-4 p-4 bg-darker rounded-lg border border-gray-700 hover:border-green-400 transition-colors group"
                  data-testid="contact-whatsapp"
                >
                  <i className="fab fa-whatsapp text-green-400 text-xl"></i>
                  <div>
                    <div className="font-semibold group-hover:text-green-400 transition-colors">WhatsApp</div>
                    <div className="text-sm text-gray-400">+91 94131 73801</div>
                  </div>
                </a>
                <a 
                  href="https://www.linkedin.com/in/harshit-aggarwal-790582201" 
                  className="flex items-center space-x-4 p-4 bg-darker rounded-lg border border-gray-700 hover:border-blue-500 transition-colors group"
                  data-testid="contact-linkedin"
                >
                  <i className="fab fa-linkedin text-blue-500 text-xl"></i>
                  <div>
                    <div className="font-semibold group-hover:text-blue-500 transition-colors">LinkedIn</div>
                    <div className="text-sm text-gray-400">Professional Network</div>
                  </div>
                </a>
              </div>
            </div>

            {/* What Happens Next */}
            <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
              <h3 className="text-xl font-bold mb-6">What Happens Next?</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-accent to-blue-accent rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                    01
                  </div>
                  <p className="text-sm text-gray-300">I'll analyze your current email performance and identify opportunities</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-accent to-blue-accent rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                    02
                  </div>
                  <p className="text-sm text-gray-300">We'll discuss your business goals and target audience in detail</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-accent to-blue-accent rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                    03
                  </div>
                  <p className="text-sm text-gray-300">I'll create a custom AI-powered email strategy for your brand</p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-accent to-blue-accent rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">
                    04
                  </div>
                  <p className="text-sm text-gray-300">You'll see measurable revenue increases within 30 days</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-purple-accent/20 to-blue-accent/20 rounded-2xl p-8 border border-gray-800">
            <h3 className="text-2xl font-bold mb-4">Free Strategy Session</h3>
            <p className="text-gray-300">
              No commitment required. Let's discuss how AI can transform your email marketing and drive real revenue growth.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
