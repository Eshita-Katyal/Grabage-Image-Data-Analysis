export default function ExperienceTimeline() {
  return (
    <section className="py-20 px-6 bg-darker/30">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-16">Experience Timeline</h2>
        
        <div className="space-y-8">
          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800 hover:border-blue-accent/50 transition-all duration-300">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-accent to-blue-accent rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="fas fa-briefcase text-white"></i>
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                  <h3 className="text-xl font-bold">Head of Marketing & Business Development</h3>
                  <span className="text-green-400 px-3 py-1 bg-green-400/20 rounded-full text-sm">Current</span>
                </div>
                <p className="text-blue-accent mb-2">Uni2Work • Jan 2025 - Present</p>
                <p className="text-gray-300">Leading marketing strategies and business development initiatives, focusing on AI-driven solutions and scalable growth systems.</p>
              </div>
            </div>
          </div>

          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-gray-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="fas fa-users text-white"></i>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">Junior Manager (Multiple Roles)</h3>
                <p className="text-blue-accent mb-2">AIESEC in India • 2023 - 2024</p>
                <p className="text-gray-300">Managed international talent exchange programs and strategic partnerships.</p>
              </div>
            </div>
          </div>

          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-gray-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <i className="fas fa-handshake text-white"></i>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">Customer Relationship Officer</h3>
                <p className="text-blue-accent mb-2">Tommy Hilfiger • May - Jun 2024</p>
                <p className="text-gray-300">Enhanced customer experience and relationship management strategies.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
