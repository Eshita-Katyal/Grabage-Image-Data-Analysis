import AnimatedCounter from "@/components/animated-counter";

export default function CampaignResults() {
  return (
    <section id="results" className="py-20 px-6 bg-darker/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-8">
            This Email Generated <span className="gradient-text">$47,000</span> in Revenue
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A real campaign I created for a retail client during Black Friday. Every element was AI-optimized for maximum engagement and conversion.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
          <div className="text-center" data-testid="metric-revenue">
            <div className="text-4xl font-bold gradient-text mb-2">
              $<AnimatedCounter target={47} />K
            </div>
            <div className="text-gray-400">Revenue Generated</div>
          </div>
          <div className="text-center" data-testid="metric-open-rate">
            <div className="text-4xl font-bold gradient-text mb-2">
              <AnimatedCounter target={35} />%
            </div>
            <div className="text-gray-400">Open Rate</div>
          </div>
          <div className="text-center" data-testid="metric-click-rate">
            <div className="text-4xl font-bold gradient-text mb-2">
              <AnimatedCounter target={12} />.<AnimatedCounter target={8} />%
            </div>
            <div className="text-gray-400">Click Rate</div>
          </div>
          <div className="text-center" data-testid="metric-conversion-rate">
            <div className="text-4xl font-bold gradient-text mb-2">
              <AnimatedCounter target={4} />.<AnimatedCounter target={2} />%
            </div>
            <div className="text-gray-400">Conversion Rate</div>
          </div>
        </div>

        {/* Campaign Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
            <h3 className="text-2xl font-bold mb-6">Subject Line Analysis</h3>
            <div className="bg-darker rounded-xl p-6 border border-gray-700 mb-6">
              <p className="text-lg font-medium mb-4">"Sarah, your exclusive 25% holiday deals expire in 24 hours! 🎄"</p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-2"></i>
                  <span>AI-personalized with recipient data</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-2"></i>
                  <span>Urgency-driven language</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-2"></i>
                  <span>Optimal character count (47 chars)</span>
                </div>
                <div className="flex items-center text-green-400">
                  <i className="fas fa-check mr-2"></i>
                  <span>Emotional trigger words</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800">
            <h3 className="text-2xl font-bold mb-6">AI Personalization Features</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <i className="fas fa-brain text-blue-accent mt-1"></i>
                <div>
                  <h4 className="font-semibold">Dynamic Product Recommendations</h4>
                  <p className="text-sm text-gray-400">AI analyzed browsing history to show relevant products</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="fas fa-users text-purple-accent mt-1"></i>
                <div>
                  <h4 className="font-semibold">Behavioral Segmentation</h4>
                  <p className="text-sm text-gray-400">Content adapted based on customer journey stage</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="fas fa-clock text-green-400 mt-1"></i>
                <div>
                  <h4 className="font-semibold">Optimal Send Time</h4>
                  <p className="text-sm text-gray-400">AI determined best time for each recipient</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="fas fa-palette text-orange-400 mt-1"></i>
                <div>
                  <h4 className="font-semibold">Brand-Consistent Design</h4>
                  <p className="text-sm text-gray-400">Custom styling that matches client's visual identity</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
