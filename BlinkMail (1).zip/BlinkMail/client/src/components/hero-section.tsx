import AnimatedCounter from "@/components/animated-counter";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="pt-32 pb-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="inline-flex items-center px-4 py-2 bg-blue-accent/20 rounded-full mb-6">
            <i className="fas fa-magic text-blue-accent mr-2"></i>
            <span className="text-blue-accent font-medium">AI-Powered Email Marketing Expert</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
            Transform Your<br />
            <span className="gradient-text">Email Marketing</span><br />
            With AI Power
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-12">
            I create AI-powered email campaigns that generate real revenue. My clients see{' '}
            <span className="text-blue-accent font-semibold">35% higher open rates</span> and{' '}
            <span className="text-purple-accent font-semibold">200% better conversions</span> within 30 days.
          </p>
        </div>

        {/* Animated Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-darker/50 backdrop-blur-sm rounded-2xl p-8 text-center border border-gray-800 hover:border-blue-accent/50 transition-all duration-300">
            <div className="text-4xl font-bold gradient-text mb-2">
              <AnimatedCounter target={35} />
            </div>
            <div className="text-lg font-medium mb-1">%</div>
            <div className="text-gray-400">Higher Open Rates</div>
          </div>
          <div className="bg-darker/50 backdrop-blur-sm rounded-2xl p-8 text-center border border-gray-800 hover:border-purple-accent/50 transition-all duration-300">
            <div className="text-4xl font-bold gradient-text mb-2">
              <AnimatedCounter target={200} />
            </div>
            <div className="text-lg font-medium mb-1">%</div>
            <div className="text-gray-400">Better Click Rates</div>
          </div>
          <div className="bg-darker/50 backdrop-blur-sm rounded-2xl p-8 text-center border border-gray-800 hover:border-blue-accent/50 transition-all duration-300">
            <div className="text-4xl font-bold gradient-text mb-2">
              <AnimatedCounter target={20} />
            </div>
            <div className="text-lg font-medium mb-1">%</div>
            <div className="text-gray-400">More Revenue</div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <button 
            onClick={() => scrollToSection('results')}
            className="gradient-bg text-white px-8 py-4 rounded-xl font-semibold text-lg hover:scale-105 transition-transform duration-300 animate-glow"
            data-testid="button-view-campaign"
          >
            <i className="fas fa-envelope mr-2"></i>
            View $47K Email Campaign
          </button>
          <button 
            onClick={() => scrollToSection('contact')}
            className="border border-blue-accent text-blue-accent px-8 py-4 rounded-xl font-semibold text-lg hover:bg-blue-accent hover:text-white transition-all duration-300"
            data-testid="button-get-strategy"
          >
            <i className="fas fa-strategy mr-2"></i>
            Get My Free Strategy
          </button>
        </div>

        {/* Achievement Badges */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-16">
          <div className="flex items-center justify-center space-x-3 text-sm text-gray-400">
            <i className="fas fa-dollar-sign text-green-400"></i>
            <span>$47K+ Revenue Generated</span>
          </div>
          <div className="flex items-center justify-center space-x-3 text-sm text-gray-400">
            <i className="fas fa-briefcase text-blue-accent"></i>
            <span>Marketing Head at Uni2Work</span>
          </div>
          <div className="flex items-center justify-center space-x-3 text-sm text-gray-400">
            <i className="fas fa-graduation-cap text-purple-accent"></i>
            <span>PGDM at ISME Bangalore</span>
          </div>
        </div>
      </div>
    </section>
  );
}
