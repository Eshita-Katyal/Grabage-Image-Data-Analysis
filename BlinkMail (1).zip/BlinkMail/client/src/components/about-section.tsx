import harshitPhoto from "@assets/photo harshit pasport size_11zon_1754899261645.jpg";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <img 
              src={harshitPhoto} 
              alt="Harshit Aggarwal - Professional headshot" 
              className="rounded-2xl shadow-2xl w-full max-w-md mx-auto animate-float"
              data-testid="img-professional-headshot"
            />
            <div className="text-center mt-6">
              <div className="inline-flex items-center px-4 py-2 bg-green-500/20 rounded-full">
                <div className="w-3 h-3 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                <span className="text-green-400 font-medium">Available for Opportunities</span>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-4xl font-bold mb-8">Meet Harshit Aggarwal</h2>
            <p className="text-gray-300 text-lg leading-relaxed mb-8">
              A passionate PGDM student and marketing leader who blends AI-powered innovation with strategic business growth
            </p>
            
            <div className="bg-darker/50 rounded-2xl p-8 border border-gray-800 mb-8">
              <h3 className="text-2xl font-bold mb-4">Harshit Aggarwal</h3>
              <p className="text-blue-accent mb-2">PGDM Student & Marketing Head</p>
              <p className="text-gray-400 mb-6">Bengaluru, Karnataka • ISME Bangalore</p>
              
              <div className="flex space-x-4">
                <a 
                  href="mailto:harshitanshu18@gmail.com" 
                  className="text-blue-accent hover:text-white transition-colors"
                  data-testid="link-email"
                >
                  <i className="fas fa-envelope"></i> Email Me
                </a>
                <a 
                  href="https://www.linkedin.com/in/harshitaggarwal-790582201" 
                  className="text-blue-accent hover:text-white transition-colors"
                  data-testid="link-linkedin"
                >
                  <i className="fab fa-linkedin"></i> LinkedIn
                </a>
              </div>
            </div>

            <div className="space-y-6">
              <p className="text-gray-300 leading-relaxed">
                I'm a first-year PGDM student at ISME, Bangalore, with a deep passion for the financial industry, strategic marketing, and AI-powered business solutions. My journey is driven by a desire to blend creativity, technology, and strategic insight to solve real-world business challenges.
              </p>
              <p className="text-gray-300 leading-relaxed">
                As the Marketing Head at Uni2Work, I lead high-impact campaigns that bridge creativity and conversion, turning insights into action and ideas into measurable results. This experience has honed my leadership skills and reinforced my belief in the power of data-driven decision-making.
              </p>
              <p className="text-gray-300 leading-relaxed">
                Currently, I'm channeling my experience into building AI-driven automation systems that enhance business efficiency and scale lead generation. I specialize in crafting custom workflows for personalized bulk mailing, campaign automation, and prompt engineering—solutions that solve business bottlenecks, improve engagement, and drive smarter decision-making.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
