import { useCounterAnimation } from '@/hooks/use-counter-animation';

interface AnimatedCounterProps {
  target: number;
  suffix?: string;
  className?: string;
  duration?: number;
}

export default function AnimatedCounter({ 
  target, 
  suffix = '', 
  className = '', 
  duration = 2000 
}: AnimatedCounterProps) {
  const { count, elementRef } = useCounterAnimation(target, duration);

  return (
    <div ref={elementRef} className={className} data-testid={`counter-${target}`}>
      {count}{suffix}
    </div>
  );
}
