import AnimatedCounter from "@/components/animated-counter";

interface Skill {
  name: string;
  percentage: number;
  description: string;
  color: string;
}

const skills: Skill[] = [
  {
    name: "Marketing Automation",
    percentage: 95,
    description: "Advanced automation workflows and trigger-based campaigns",
    color: "from-purple-accent to-blue-accent"
  },
  {
    name: "Email Marketing", 
    percentage: 98,
    description: "High-converting email design and optimization strategies",
    color: "from-purple-accent to-blue-accent"
  },
  {
    name: "Prompt Design",
    percentage: 92, 
    description: "AI prompt engineering for personalized content generation",
    color: "from-green-400 to-blue-accent"
  },
  {
    name: "AI Workflow Design",
    percentage: 90,
    description: "Custom AI-driven automation systems and workflows", 
    color: "from-orange-400 to-blue-accent"
  },
  {
    name: "Business Development",
    percentage: 88,
    description: "Strategic partnerships and growth initiatives",
    color: "from-blue-accent to-purple-accent"
  },
  {
    name: "Strategic Marketing",
    percentage: 94,
    description: "Data-driven marketing strategies and campaign optimization",
    color: "from-purple-accent to-blue-accent"
  }
];

const achievements = [
  {
    icon: "fas fa-dollar-sign",
    value: 47,
    suffix: "K+",
    label: "Revenue Impact Leader",
    color: "from-green-400 to-blue-accent"
  },
  {
    icon: "fas fa-users", 
    value: 200,
    suffix: "+",
    label: "Global Program Manager",
    color: "from-purple-accent to-blue-accent"
  },
  {
    icon: "fas fa-handshake",
    value: 15,
    suffix: "+", 
    label: "Strategic Partnership Builder",
    color: "from-blue-accent to-green-400"
  },
  {
    icon: "fas fa-robot",
    value: 300,
    suffix: "+",
    label: "AI Automation Specialist", 
    color: "from-orange-400 to-purple-accent"
  },
  {
    icon: "fas fa-chart-line",
    value: 35,
    suffix: "%",
    label: "Campaign Automation Expert",
    color: "from-green-400 to-purple-accent"
  }
];

export default function SkillsSection() {
  return (
    <section id="skills" className="py-20 px-6 bg-darker/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-8">
            Skills That Drive <span className="gradient-text">Real Results</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A comprehensive toolkit of AI-powered marketing skills that transform email campaigns into revenue machines
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {skills.map((skill, index) => (
            <div 
              key={skill.name}
              className="bg-darker/50 rounded-2xl p-8 border border-gray-800 hover:border-blue-accent/50 transition-all duration-300"
              data-testid={`skill-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">{skill.name}</h3>
                <span className="text-blue-accent font-bold">
                  <AnimatedCounter target={skill.percentage} />%
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3 mb-4">
                <div 
                  className={`bg-gradient-to-r ${skill.color} h-3 rounded-full transition-all duration-1000 ease-out`}
                  style={{ width: `${skill.percentage}%` }}
                ></div>
              </div>
              <p className="text-gray-400 text-sm">{skill.description}</p>
            </div>
          ))}
        </div>

        {/* Key Achievements */}
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold mb-8">Key Achievements</h3>
          <p className="text-gray-300 mb-12">Measurable results that showcase the power of AI-driven email marketing</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {achievements.map((achievement, index) => (
            <div 
              key={achievement.label}
              className="text-center"
              data-testid={`achievement-${index}`}
            >
              <div className={`w-20 h-20 bg-gradient-to-r ${achievement.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <i className={`${achievement.icon} text-white text-2xl`}></i>
              </div>
              <div className="text-2xl font-bold gradient-text mb-2">
                <AnimatedCounter target={achievement.value} />{achievement.suffix}
              </div>
              <p className="text-sm text-gray-400">{achievement.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
